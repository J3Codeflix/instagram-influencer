export interface Places {
    name:string;
    pk:string;
    short_name:string;
    external_source:string;
    title:string;
    position:number;
    slug:string;
}